﻿using ObjectComparer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Object_ComparerRunner
{
    class Program
    {
        static void Main(string[] args)
        {
            Creator factory = new Creator();

            ICustomComparer primitive = factory.FactoryMethod("Primitive");
           bool result= primitive.compare(1, 1);



            Console.ReadKey();
        }
    }
}
