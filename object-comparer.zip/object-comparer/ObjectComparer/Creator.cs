﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectComparer
{
   public class Creator
    {
        public  ICustomComparer FactoryMethod(string type)
        {
            switch (type)
            {
                case "Primitive": 
                    return new PrimitiveTypeComparer();
                case "List":
                    return new ListComparer();

                default: 
                    throw new ArgumentException("Invalid type", "type");
            }
        }
    }
}
